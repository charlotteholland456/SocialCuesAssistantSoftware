cd $PSScriptRoot
py -3.11 plugin.py
