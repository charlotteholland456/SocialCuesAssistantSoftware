import requests
import speech_recognition as sr
import PySimpleGUI as sg

USER_CONSENT = False


# -----------------------------
# Consent popup (PySimpleGUI)
# -----------------------------
def consent_check_record():
    global USER_CONSENT

    layout = [
        [sg.Text("Require audio recording transcript?")],
        [sg.Button("Yes"), sg.Button("No")]
    ]

    window = sg.Window("Social Cue Assistant", layout)
    event, _ = window.read()
    window.close()

    if event == "Yes":
        print("User Consent")
        USER_CONSENT = True
    else:
        print("User Declined")
        USER_CONSENT = False


# -----------------------------
# Send transcript line to your server
# -----------------------------
def send_transcript_line(text):
    try:
        requests.post(
            "http://127.0.0.1:5000/transcript",
            data={"text": text}
        )
        print("Sent:", text)
    except Exception as e:
        print("Error:", e)


# -----------------------------
# Main plugin logic
# -----------------------------
def main():
    global USER_CONSENT

    # Ask for consent immediately
    consent_check_record()

    if not USER_CONSENT:
        print("Recording disabled.")
        return

    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    print("Plugin listening... speak now.")

    while True:
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)

        try:
            text = recognizer.recognize_google(audio)
            send_transcript_line(f"User: {text}")
        except sr.UnknownValueError:
            print("Didn't catch that.")
        except sr.RequestError as e:
            print("Speech recognition error:", e)


# -----------------------------
# Run plugin
# -----------------------------
if __name__ == "__main__":
    main()
